package com.example.vedranivic.smartbin.Model;

public class User {

    private String distance;

    private String percentage;

    private String maxDistance;

    private String id;

    private String time;

    public String getDistance ()
    {
        return distance;
    }

    public String getPercentage ()
    {
        return percentage;
    }

    public String getMaxDistance ()
    {
        return maxDistance;
    }

    public void setMaxDistance (String maxDistance)
    {
        this.maxDistance = maxDistance;
    }

    public String getId ()
    {
        return id;
    }

    public void setId (String id)
    {
        this.id = id;
    }

    public String getTime ()
    {
        return time;
    }

    public void setTime (String time)
    {
        this.time = time;
    }

}
